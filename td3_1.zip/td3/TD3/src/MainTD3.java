import View.TreeView;


public class MainTD3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		td3();
	}
	
	public static void td3() {
		TreeView v = new TreeView();
	}

}
