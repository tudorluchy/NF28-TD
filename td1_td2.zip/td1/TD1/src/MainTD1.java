import View.ConsoleView;
import View.ImageView;


public class MainTD1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		td1();
	}
	
	public static void td1() {
		new ImageView("ImageView1");
		new ImageView("ImageView2");
		new ConsoleView("ConsoleView");
	}

}
