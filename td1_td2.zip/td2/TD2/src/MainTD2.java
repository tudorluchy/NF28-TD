import View.ListView;



public class MainTD2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		td2();
	}
	
	public static void td2() {
		ListView view = new ListView();
	}

}
